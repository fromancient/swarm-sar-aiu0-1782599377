"""
Swarm Subnet 124 — Hybrid V5 search-and-rescue flight controller.

Single-file submission entrypoint with internal modules:
  depth preprocessing, state parsing, optional neural policy,
  mission state machine, safety shield, RGB scheduler.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from enum import Enum, auto
from pathlib import Path

import numpy as np

try:
    import torch
    import torch.nn as nn

    _TORCH = True
except ImportError:  # pragma: no cover
    _TORCH = False
    torch = None  # type: ignore
    nn = None  # type: ignore


# ---------------------------------------------------------------------------
# State parsing
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FlightState:
    position: np.ndarray
    orientation: np.ndarray
    linear_velocity: np.ndarray
    angular_velocity: np.ndarray
    altitude_norm: float
    search_clue_xy: np.ndarray
    speed: float
    horizontal_speed: float
    yaw: float


def _parse_state(state: np.ndarray) -> FlightState:
    s = np.asarray(state, dtype=np.float32).reshape(-1)
    if s.shape[0] < 16:
        raise ValueError(f"state vector too short: {s.shape[0]}")
    pos = s[0:3]
    orient = s[3:6]
    lin_vel = s[6:9]
    ang_vel = s[9:12]
    clue = s[-2:]
    alt_norm = float(s[-3])
    speed = float(np.linalg.norm(lin_vel))
    horizontal_speed = float(np.linalg.norm(lin_vel[:2]))
    yaw = float(orient[2])
    return FlightState(
        position=pos,
        orientation=orient,
        linear_velocity=lin_vel,
        angular_velocity=ang_vel,
        altitude_norm=alt_norm,
        search_clue_xy=clue,
        speed=speed,
        horizontal_speed=horizontal_speed,
        yaw=yaw,
    )


# ---------------------------------------------------------------------------
# Depth analysis
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DepthFeatures:
    front_min: float
    left_min: float
    right_min: float
    bottom_min: float
    top_min: float
    center_bottom_min: float
    ground_slope: float
    victim_score: float
    clearance: float
    victim_lateral: float
    victim_range: float


@dataclass(frozen=True)
class VictimDetection:
    score: float
    lateral: float
    locked: bool
    source: str
    range_norm: float = 0.5


def _sector_min(depth: np.ndarray, row_slice: slice, col_slice: slice) -> float:
    patch = depth[row_slice, col_slice]
    if patch.ndim == 3:
        patch = patch[:, :, 0]
    valid = patch[(patch > 0.02) & (patch < 0.98)]
    if valid.size == 0:
        return 1.0
    return float(np.min(valid))


def _mean_valid(patch: np.ndarray, default: float = 0.5) -> float:
    valid = patch[(patch > 0.02) & (patch < 0.98)]
    if valid.size == 0:
        return default
    return float(np.mean(valid))


def _analyze_depth(depth: np.ndarray) -> DepthFeatures:
    d = np.asarray(depth, dtype=np.float32)
    if d.ndim == 3:
        d = d[:, :, 0]
    h, w = d.shape

    front_min = _sector_min(d, slice(int(h * 0.35), h), slice(int(w * 0.25), int(w * 0.75)))
    left_min = _sector_min(d, slice(int(h * 0.2), h), slice(0, int(w * 0.35)))
    right_min = _sector_min(d, slice(int(h * 0.2), h), slice(int(w * 0.65), w))
    bottom_min = _sector_min(d, slice(int(h * 0.65), h), slice(int(w * 0.2), int(w * 0.8)))
    top_min = _sector_min(d, slice(0, int(h * 0.35)), slice(int(w * 0.25), int(w * 0.75)))
    center_bottom_min = _sector_min(
        d, slice(int(h * 0.55), h), slice(int(w * 0.35), int(w * 0.65))
    )

    lower = d[int(h * 0.55) :, int(w * 0.3) : int(w * 0.7)]
    upper = d[int(h * 0.25) : int(h * 0.45), int(w * 0.3) : int(w * 0.7)]
    ground_slope = _mean_valid(lower) - _mean_valid(upper)

    col_center = d[int(h * 0.5) :, int(w * 0.4) : int(w * 0.6)]
    col_left = d[int(h * 0.5) :, int(w * 0.15) : int(w * 0.35)]
    col_right = d[int(h * 0.5) :, int(w * 0.65) : int(w * 0.85)]
    center_valid = col_center[(col_center > 0.02) & (col_center < 0.98)]
    center_var = float(np.std(center_valid)) if center_valid.size else 0.0
    side_valid = np.concatenate(
        [
            col_left[(col_left > 0.02) & (col_left < 0.98)],
            col_right[(col_right > 0.02) & (col_right < 0.98)],
        ]
    )
    side_mean = float(np.mean(side_valid)) if side_valid.size else 0.5
    center_mean = _mean_valid(col_center)
    victim_score = max(0.0, (side_mean - center_mean) * 1.4 + center_var * 1.0)

    # Humanoid blob bearing from mid-range depth pixels only (ignore ground/platform).
    lower_band = d[int(h * 0.50) : int(h * 0.88), int(w * 0.15) : int(w * 0.85)]
    valid_mask = (lower_band > 0.06) & (lower_band < 0.55)
    victim_lateral = 0.0
    victim_range = 1.0
    if np.any(valid_mask):
        rows, cols = np.where(valid_mask)
        weights = 1.0 - lower_band[rows, cols]
        col_centroid = float(np.average(cols, weights=weights + 1e-6))
        col_offset = col_centroid - (lower_band.shape[1] * 0.5)
        victim_lateral = float(np.clip(col_offset / (lower_band.shape[1] * 0.45), -1.0, 1.0))
        victim_range = float(np.average(lower_band[rows, cols], weights=weights))

        col_scores = []
        for frac in (0.35, 0.42, 0.50, 0.58, 0.65):
            c0, c1 = int(w * (frac - 0.04)), int(w * (frac + 0.04))
            patch = d[int(h * 0.52) : int(h * 0.88), c0:c1]
            pv = patch[(patch > 0.06) & (patch < 0.55)]
            if pv.size >= 8:
                col_scores.append(float(np.std(pv)) + float(0.45 - np.mean(pv)))
        if col_scores:
            blob_score = max(col_scores) * 1.1
            if victim_range < 0.48:
                victim_score = max(victim_score, blob_score)

    all_valid = d[(d > 0.02) & (d < 0.98)]
    clearance = float(np.min(all_valid)) if all_valid.size else 1.0

    return DepthFeatures(
        front_min=front_min,
        left_min=left_min,
        right_min=right_min,
        bottom_min=bottom_min,
        top_min=top_min,
        center_bottom_min=center_bottom_min,
        ground_slope=ground_slope,
        victim_score=victim_score,
        clearance=clearance,
        victim_lateral=victim_lateral,
        victim_range=victim_range,
    )


def _detect_victim_rgb(rgb: np.ndarray) -> VictimDetection:
    h, w, _ = rgb.shape
    lower = rgb[int(h * 0.40) :, int(w * 0.20) : int(w * 0.80), :]
    if lower.size == 0 or float(np.max(lower)) < 0.01:
        return VictimDetection(0.0, 0.0, False, "rgb")

    r, g, b = lower[..., 0], lower[..., 1], lower[..., 2]
    # Skin / clothing / humanoid silhouette heuristics.
    skin = (r > 0.30) & (g > 0.18) & (b > 0.12) & (r >= g) & (g >= b * 0.75)
    dark_clothes = (r < 0.35) & (g < 0.35) & (b < 0.40) & ((r + g + b) > 0.15)
    blob = skin | dark_clothes
    if not np.any(blob):
        return VictimDetection(0.0, 0.0, False, "rgb")

    rows, cols = np.where(blob)
    weights = lower[rows, cols, 0] + lower[rows, cols, 1] + lower[rows, cols, 2]
    col_centroid = float(np.average(cols, weights=weights + 1e-6))
    lateral = float(np.clip((col_centroid - (lower.shape[1] * 0.5)) / (lower.shape[1] * 0.45), -1.0, 1.0))
    score = float(np.mean(blob)) * 2.8 + float(np.std(blob.astype(np.float32))) * 0.5
    row_span = float(rows.max() - rows.min()) / max(h * 0.48, 1.0)
    if row_span > 0.18:
        score += 0.12
    locked = score > 0.32 and abs(lateral) < 0.22
    return VictimDetection(score, lateral, locked, "rgb")


def _rgb_descent_ok(victim: VictimDetection, rgb_det: VictimDetection | None) -> bool:
    """Only descend on victim when RGB confirms a centered humanoid (not floor clutter)."""
    if rgb_det is not None and rgb_det.score > 0.26 and abs(rgb_det.lateral) < 0.22:
        return True
    return "rgb" in victim.source and victim.score > 0.28 and abs(victim.lateral) < 0.20


def _descent_confirm_ok(
    victim: VictimDetection,
    rgb_det: VictimDetection | None,
    depth: DepthFeatures,
) -> bool:
    """RGB-preferred; fall back to strong centered depth lock when RGB unavailable."""
    if _rgb_descent_ok(victim, rgb_det):
        return True
    return (
        victim.score > 0.38
        and abs(victim.lateral) < 0.14
        and 0.06 < depth.victim_range < 0.34
        and depth.victim_score > 0.32
    )


def _fuse_victim_detection(depth: DepthFeatures, rgb_det: VictimDetection | None) -> VictimDetection:
    depth_score = depth.victim_score
    depth_lat = depth.victim_lateral
    depth_close = 0.05 < depth.victim_range < 0.48
    depth_locked = depth_score > 0.44 and depth_close
    if rgb_det is None or rgb_det.score <= 0.0:
        return VictimDetection(depth_score, depth_lat, depth_locked, "depth")
    if rgb_det.score >= depth_score:
        return VictimDetection(
            max(depth_score, rgb_det.score),
            rgb_det.lateral if abs(rgb_det.lateral) > 0.05 else depth_lat,
            rgb_det.locked or depth_locked,
            "rgb+depth" if depth_score > 0.20 else "rgb",
        )
    return VictimDetection(depth_score, depth_lat, depth_locked, "depth")


# ---------------------------------------------------------------------------
# Altitude helpers (altitude_norm = meters_below / 20)
# ---------------------------------------------------------------------------

# SAR depth map: normalized [0,1] over [DEPTH_MIN_M, SAR_DEPTH_MAX_M] (see moving_drone._process_depth)
_SAR_DEPTH_MIN_M = 0.5
_SAR_DEPTH_MAX_M = 30.0
_SAR_DEPTH_SPAN_M = _SAR_DEPTH_MAX_M - _SAR_DEPTH_MIN_M
_SAR_HOVER_LO_M = 2.0
_SAR_HOVER_HI_M = 4.0
_SAR_HOVER_TARGET_M = 3.0


def _depth_norm_to_meters(d_norm: float) -> float:
    return _SAR_DEPTH_MIN_M + float(np.clip(d_norm, 0.0, 1.0)) * _SAR_DEPTH_SPAN_M


def _surface_range_m(
    depth: DepthFeatures,
    victim: VictimDetection | None = None,
    *,
    rgb_gated: bool = False,
) -> float:
    """Estimate meters to victim/surface. Ignores floor depth unless RGB confirms victim."""
    if victim is not None and victim.score > 0.26 and 0.03 < depth.victim_range < 0.90:
        if rgb_gated or "rgb" in victim.source:
            return _depth_norm_to_meters(depth.victim_range)
    if not rgb_gated:
        return _SAR_DEPTH_MAX_M
    candidates = [depth.victim_range, depth.center_bottom_min, depth.bottom_min]
    valid = [c for c in candidates if 0.03 < c < 0.95]
    if not valid:
        return _SAR_DEPTH_MAX_M
    return min(_depth_norm_to_meters(c) for c in valid)


def _in_hover_band_m(surface_m: float) -> bool:
    return _SAR_HOVER_LO_M <= surface_m <= _SAR_HOVER_HI_M + 0.5


_ALT_NORM_M = 20.0
_HOVER_ALT_LO = 2.0 / _ALT_NORM_M
_HOVER_ALT_HI = 4.0 / _ALT_NORM_M
_HOVER_ALT_TARGET = 3.0 / _ALT_NORM_M
_HOVER_SPEED_ACTION = 0.18
_APPROACH_HORIZ_M = 2.0


# ---------------------------------------------------------------------------
# Mission phases
# ---------------------------------------------------------------------------


class MissionPhase(Enum):
    TRANSIT = auto()
    APPROACH = auto()
    SEARCH_RING_1 = auto()
    SEARCH_RING_2 = auto()
    TARGET_ALIGN = auto()
    DESCEND_WHILE_CLOSING = auto()
    DESCEND_LOCKED = auto()
    CREEP_OVER_TARGET = auto()
    HOVER_CONFIRM = auto()
    RECOVERY = auto()


# ---------------------------------------------------------------------------
# Victim target localization
# ---------------------------------------------------------------------------


@dataclass
class TargetCandidate:
    bearing: float
    image_x: float
    range_m: float
    rgb_score: float
    depth_score: float
    consistency_count: int
    last_seen_step: int
    vertical_plausibility: float
    bearing_var: float

    @property
    def combined_score(self) -> float:
        return self.rgb_score * 0.55 + self.depth_score * 0.45 + min(self.consistency_count, 6) * 0.04

    def stable(self) -> bool:
        return (
            self.consistency_count >= 4
            and self.rgb_score >= 0.26
            and self.depth_score >= 0.24
            and abs(self.image_x) < 0.20
            and self.bearing_var < 0.06
            and self.vertical_plausibility > 0.14
        )


class TargetTracker:
    """Multi-frame RGB+depth victim localizer near the search clue."""

    _BIN_RAD = 0.22
    _DECAY_STEPS = 45

    def __init__(self) -> None:
        self._candidates: dict[int, TargetCandidate] = {}
        self._locked: TargetCandidate | None = None
        self._lock_step = -1
        self._prev_range_m: float | None = None
        self._descent_reason = "none"
        self._search_ring = 1
        self._yaw_sweep = 0.0

    def reset(self) -> None:
        self._candidates.clear()
        self._locked = None
        self._lock_step = -1
        self._prev_range_m = None
        self._descent_reason = "none"
        self._search_ring = 1
        self._yaw_sweep = float(np.random.uniform(-0.4, 0.4))

    @property
    def locked(self) -> bool:
        return self._locked is not None

    @property
    def descent_reason(self) -> str:
        return self._descent_reason

    @property
    def search_ring(self) -> int:
        return self._search_ring

    def set_search_ring(self, ring: int) -> None:
        self._search_ring = int(np.clip(ring, 1, 2))

    def best(self) -> TargetCandidate | None:
        if self._locked is not None:
            return self._locked
        if not self._candidates:
            return None
        return max(self._candidates.values(), key=lambda c: c.combined_score)

    def count(self) -> int:
        return len(self._candidates)

    def observe(
        self,
        step: int,
        flight: FlightState,
        depth: DepthFeatures,
        rgb_det: VictimDetection | None,
        *,
        rgb_frame_valid: bool,
        cnn_det: VictimDetection | None = None,
        clue_dist: float = 999.0,
    ) -> None:
        stale = [k for k, c in self._candidates.items() if step - c.last_seen_step > self._DECAY_STEPS]
        for k in stale:
            del self._candidates[k]

        obs_list: list[tuple[float, float, float, float, float, float]] = []
        perception = None
        if cnn_det is not None and cnn_det.score > 0.12:
            perception = cnn_det
        elif rgb_det is not None and rgb_frame_valid and rgb_det.score > 0.12:
            perception = rgb_det

        if perception is not None:
            bearing = float(flight.yaw + perception.lateral * 0.42)
            if perception.source == "cnn":
                range_m = _depth_norm_to_meters(perception.range_norm)
                rgb_s = perception.score
                depth_s = max(depth.victim_score * 0.35, perception.score * 0.25)
            else:
                range_m = _depth_norm_to_meters(depth.victim_range)
                if 0.06 < depth.victim_range < 0.55:
                    range_m = _depth_norm_to_meters(depth.victim_range)
                rgb_s = perception.score
                depth_s = depth.victim_score
            vert = 0.28 if perception.score > 0.30 else 0.16
            obs_list.append((bearing, perception.lateral, range_m, rgb_s, depth_s, vert))

        allow_depth = perception is None or perception.score < 0.22
        if allow_depth and depth.victim_score > 0.30 and 0.06 < depth.victim_range < 0.48:
            bearing = float(flight.yaw + depth.victim_lateral * 0.40)
            range_m = _depth_norm_to_meters(depth.victim_range)
            vert = min(0.30, depth.victim_score * 0.45)
            if not obs_list or abs(obs_list[0][1] - depth.victim_lateral) > 0.25:
                obs_list.append(
                    (bearing, depth.victim_lateral, range_m, 0.0, depth.victim_score, vert)
                )

        for bearing, image_x, range_m, rgb_s, depth_s, vert in obs_list:
            key = int(np.round(bearing / self._BIN_RAD))
            prev = self._candidates.get(key)
            if prev is None:
                self._candidates[key] = TargetCandidate(
                    bearing=bearing,
                    image_x=image_x,
                    range_m=range_m,
                    rgb_score=rgb_s,
                    depth_score=depth_s,
                    consistency_count=1,
                    last_seen_step=step,
                    vertical_plausibility=vert,
                    bearing_var=0.0,
                )
            else:
                bdiff = float(np.arctan2(np.sin(bearing - prev.bearing), np.cos(bearing - prev.bearing)))
                new_var = prev.bearing_var * 0.6 + abs(bdiff) * 0.4
                self._candidates[key] = TargetCandidate(
                    bearing=bearing * 0.35 + prev.bearing * 0.65,
                    image_x=image_x * 0.45 + prev.image_x * 0.55,
                    range_m=range_m * 0.40 + prev.range_m * 0.60,
                    rgb_score=max(rgb_s, prev.rgb_score * 0.85),
                    depth_score=max(depth_s, prev.depth_score * 0.85),
                    consistency_count=min(prev.consistency_count + 1, 12),
                    last_seen_step=step,
                    vertical_plausibility=max(vert, prev.vertical_plausibility * 0.8),
                    bearing_var=new_var,
                )

        best = self.best()
        confirm = cnn_det if cnn_det is not None and cnn_det.score >= 0.26 else rgb_det
        lock_ok = clue_dist < 24.0 or (best is not None and best.range_m < 10.0)
        if self._locked is None and best is not None and best.stable() and lock_ok:
            if confirm is not None and confirm.score >= 0.26 and (
                cnn_det is not None or rgb_frame_valid
            ):
                self._locked = best
                self._lock_step = step
            elif (
                best.rgb_score >= 0.30
                and best.consistency_count >= 6
                and abs(best.image_x) < 0.14
            ):
                self._locked = best
                self._lock_step = step

        if self._locked is not None and clue_dist > 22.0 and best is not None and best.range_m > 11.0:
            self._locked = None
            self._lock_step = -1
            best = self.best()

        if self._locked is not None and best is not None:
            self._locked = TargetCandidate(
                bearing=best.bearing * 0.25 + self._locked.bearing * 0.75,
                image_x=best.image_x * 0.40 + self._locked.image_x * 0.60,
                range_m=best.range_m * 0.45 + self._locked.range_m * 0.55,
                rgb_score=max(best.rgb_score, self._locked.rgb_score * 0.9),
                depth_score=max(best.depth_score, self._locked.depth_score * 0.9),
                consistency_count=min(self._locked.consistency_count + 1, 20),
                last_seen_step=step,
                vertical_plausibility=max(best.vertical_plausibility, self._locked.vertical_plausibility),
                bearing_var=best.bearing_var,
            )

        if self._locked is not None and step - self._lock_step > 90:
            if best is None or best.combined_score < 0.30 or best.rgb_score < 0.18:
                self._locked = None
                self._lock_step = -1

    def descent_allowed(self, step: int, clue_dist: float = 999.0) -> bool:
        if self._locked is None:
            self._descent_reason = "no_lock"
            return False
        if self._locked.consistency_count < 4:
            self._descent_reason = "low_consistency"
            return False
        if clue_dist < 2.5 and abs(self._locked.image_x) < 0.16:
            if self._locked.consistency_count >= 4 and (
                self._locked.rgb_score >= 0.10 or self._locked.depth_score >= 0.20
            ):
                self._descent_reason = "close_horiz"
                return True
        if clue_dist < 2.5 and abs(self._locked.image_x) < 0.16:
            if self._locked.consistency_count >= 5 and (
                self._locked.rgb_score >= 0.12 or self._locked.depth_score >= 0.22
            ):
                self._descent_reason = "close_horiz"
                return True
        if self._locked.rgb_score < 0.24:
            self._descent_reason = "no_rgb_confirm"
            return False
        if self._locked.range_m > 9.0:
            self._descent_reason = "range_too_far"
            return False
        if abs(self._locked.image_x) > 0.14:
            self._descent_reason = "off_center"
            return False
        if step - self._lock_step < 5:
            self._descent_reason = "lock_warmup"
            return False
        self._descent_reason = "locked_ok"
        return True

    def range_closing(self) -> bool:
        if self._locked is None or self._prev_range_m is None:
            return False
        return self._locked.range_m <= self._prev_range_m - 0.05

    def note_range(self) -> None:
        if self._locked is not None:
            self._prev_range_m = self._locked.range_m


_SEARCH_ALT_LO = 0.35
_SEARCH_ALT_HI = 0.50
_DESCENT_STAGE1_M = 4.5
_HOVER_FINAL_SPEED = 0.08


def _victim_pursuit_dir(
    flight: FlightState,
    depth: DepthFeatures,
    lateral: float,
    *,
    close_gain: float = 1.0,
) -> tuple[float, float]:
    """Move toward a visible victim using world-forward + lateral correction."""
    yaw = flight.yaw
    fx, fy = float(np.cos(yaw)), float(np.sin(yaw))
    sx, sy = float(np.sin(yaw)), float(-np.cos(yaw))
    lat = float(np.clip(lateral, -1.0, 1.0))
    advance = float(np.clip(0.50 - depth.victim_range, 0.0, 0.38)) * close_gain
    if abs(lat) < 0.15:
        advance = max(advance, 0.30 * close_gain)
    if depth.victim_range > 0.20:
        advance = max(advance, 0.22 * close_gain)
    strafe = lat * (0.72 if abs(lat) > 0.08 else 0.35)
    dx = fx * (0.50 + advance) + sx * strafe
    dy = fy * (0.50 + advance) + sy * strafe
    norm = max(np.hypot(dx, dy), 1e-3)
    return float(dx / norm), float(dy / norm)


def _proximity_wander(spiral_angle: float, *, scale: float = 0.65) -> tuple[float, float]:
    """Slow orbit when over the clue but the victim is not yet centered."""
    dx = float(np.cos(spiral_angle)) * scale
    dy = float(np.sin(spiral_angle)) * scale
    return dx, dy


def _victim_proximity(
    depth: DepthFeatures,
    victim: VictimDetection,
    *,
    rgb_gated: bool = False,
) -> bool:
    surface_m = _surface_range_m(depth, victim, rgb_gated=rgb_gated)
    return victim.score > 0.28 and surface_m <= _SAR_HOVER_HI_M + 1.5


def _ring_orbit_dir(
    clue_xy: np.ndarray,
    *,
    ring_radius: float,
    sweep_angle: float,
) -> tuple[float, float]:
    cx, cy = float(clue_xy[0]), float(clue_xy[1])
    dist = float(np.hypot(cx, cy))
    if dist < 0.5:
        return float(np.cos(sweep_angle)), float(np.sin(sweep_angle))
    inward_x, inward_y = cx / dist, cy / dist
    tangent_x, tangent_y = -cy / dist, cx / dist
    if dist > ring_radius + 1.0:
        dx = inward_x * 0.70 + tangent_x * 0.30
        dy = inward_y * 0.70 + tangent_y * 0.30
    elif dist < ring_radius - 0.8:
        dx = -inward_x * 0.65 + tangent_x * 0.35
        dy = -inward_y * 0.65 + tangent_y * 0.35
    else:
        dx = tangent_x * 0.85 + inward_x * 0.15
        dy = tangent_y * 0.85 + inward_y * 0.15
    n = max(np.hypot(dx, dy), 1e-3)
    return float(dx / n), float(dy / n)


def _target_world_dir(flight: FlightState, candidate: TargetCandidate) -> tuple[float, float]:
    """World-frame unit direction toward candidate bearing with lateral trim."""
    cb = float(np.cos(candidate.bearing))
    sb = float(np.sin(candidate.bearing))
    perp_x, perp_y = -sb, cb
    lat = float(np.clip(candidate.image_x, -1.0, 1.0))
    dx = cb + perp_x * lat * 0.85
    dy = sb + perp_y * lat * 0.85
    n = max(np.hypot(dx, dy), 1e-3)
    return float(dx / n), float(dy / n)


def _close_on_target(
    flight: FlightState,
    depth: DepthFeatures,
    candidate: TargetCandidate,
    clue_dir_x: float,
    clue_dir_y: float,
    clue_dist: float,
    *,
    final_zone: bool = False,
) -> tuple[float, float, float, float]:
    """Yaw-first horizontal closing toward a visualized victim candidate."""
    body_x, body_y = _victim_pursuit_dir(
        flight, depth, candidate.image_x, close_gain=1.15 if not final_zone else 0.75
    )
    world_x, world_y = _target_world_dir(flight, candidate)
    blend = 0.82 if abs(candidate.image_x) < 0.14 else 0.65
    if candidate.consistency_count >= 4:
        blend = 0.90 if abs(candidate.image_x) < 0.12 else 0.78
    dir_x = world_x * blend + body_x * (1.0 - blend)
    dir_y = world_y * blend + body_y * (1.0 - blend)
    if candidate.consistency_count < 4 and clue_dist < 22.0 and candidate.range_m > clue_dist * 0.85:
        clue_w = 0.35
        dir_x = dir_x * (1.0 - clue_w) + clue_dir_x * clue_w
        dir_y = dir_y * (1.0 - clue_w) + clue_dir_y * clue_w
    n = max(np.hypot(dir_x, dir_y), 1e-3)
    dir_x, dir_y = dir_x / n, dir_y / n

    if final_zone or candidate.consistency_count >= 4:
        if candidate.range_m > 6.0:
            close_scale, speed = 0.62, 0.38
        elif candidate.range_m > 2.5:
            close_scale, speed = 0.66, 0.38
        else:
            close_scale, speed = 0.38, 0.26
    elif candidate.range_m > 10.0:
        close_scale, speed = 0.88, 0.58
    elif candidate.range_m > 6.0:
        close_scale, speed = 0.72, 0.48
    elif candidate.range_m > 3.8:
        close_scale, speed = 0.52, 0.36
    else:
        close_scale, speed = 0.30, 0.28
    dir_x *= close_scale
    dir_y *= close_scale

    if abs(candidate.image_x) > 0.12:
        speed = min(speed, 0.40)
        yaw = float(np.clip((flight.yaw + candidate.image_x * 0.72) / np.pi, -1.0, 1.0))
    else:
        yaw = float(np.clip(candidate.bearing / np.pi, -1.0, 1.0))
    return dir_x, dir_y, speed, yaw


def _estimate_surface_m(
    candidate: TargetCandidate,
    depth: DepthFeatures,
    *,
    clue_dist: float = 999.0,
) -> float:
    surface_m = candidate.range_m
    if 0.06 < depth.victim_range < 0.55:
        depth_m = _depth_norm_to_meters(depth.victim_range)
        surface_m = depth_m * 0.72 + surface_m * 0.28
    elif candidate.rgb_score >= 0.18 and 0.06 < depth.victim_range < 0.55:
        depth_m = _depth_norm_to_meters(depth.victim_range)
        surface_m = depth_m * 0.55 + surface_m * 0.45
    if clue_dist < 2.05:
        if 0.04 < depth.center_bottom_min < 0.32:
            cb_m = _depth_norm_to_meters(depth.center_bottom_min)
            surface_m = cb_m * 0.82 + surface_m * 0.18
        elif 0.04 < depth.victim_range < 0.32:
            depth_m = _depth_norm_to_meters(depth.victim_range)
            surface_m = depth_m * 0.88 + surface_m * 0.12
        surface_m = min(surface_m, clue_dist + 2.6)
    elif clue_dist < 2.5:
        surface_m = min(surface_m, clue_dist + 3.0)
    return float(surface_m)


def _final_slot_descent_z(
    surface_m: float,
    depth: DepthFeatures,
    *,
    range_m: float = 99.0,
) -> float:
    """Last-meters vertical command to enter the 2–4 m SAR hover band."""
    if range_m > 10.0:
        return -0.72
    if range_m > 6.0:
        return -0.88
    if range_m > 4.0:
        return -0.95
    if 0.04 < depth.center_bottom_min < 0.28:
        cb_m = _depth_norm_to_meters(depth.center_bottom_min)
        if cb_m <= _SAR_HOVER_LO_M - 0.15:
            return 0.10
        if cb_m <= _SAR_HOVER_HI_M + 0.05:
            return -0.12
    if surface_m > _SAR_HOVER_HI_M + 0.20:
        return -0.85
    if surface_m > _SAR_HOVER_HI_M:
        return -0.72
    if surface_m > _SAR_HOVER_TARGET_M + 0.10:
        return -0.48
    if surface_m < _SAR_HOVER_LO_M - 0.20:
        return 0.08
    return -0.16


def _horiz_proxy_m(clue_dist: float, best: TargetCandidate | None) -> float:
    """Estimate remaining horizontal distance to the victim."""
    if best is None:
        return clue_dist
    lat_penalty = abs(best.image_x) * best.range_m * 0.35
    range_horiz = max(0.0, best.range_m * 0.68 + lat_penalty)
    if best.consistency_count >= 4:
        return float(range_horiz)
    return float(min(clue_dist, range_horiz) if clue_dist < 6.0 else clue_dist)


def _creep_active(
    *,
    locked: bool,
    clue_dist: float,
    best: TargetCandidate | None,
    hover_ready: bool,
    force_target_align: bool,
) -> bool:
    if not locked or best is None or hover_ready or force_target_align:
        return False
    if clue_dist >= 4.0 or clue_dist < 2.5 or best.range_m >= 8.0:
        return False
    proxy = _horiz_proxy_m(clue_dist, best)
    return 2.0 <= proxy <= 5.0


def _descend_while_closing_active(
    *,
    locked: bool,
    clue_dist: float,
    best: TargetCandidate | None,
    depth: DepthFeatures,
    hover_ready: bool,
    force_target_align: bool,
    descent_allowed: bool,
) -> bool:
    if not locked or best is None or hover_ready or force_target_align or not descent_allowed:
        return False
    if clue_dist >= 4.0 or best.range_m >= 9.0:
        return False
    if clue_dist < 2.5:
        return False
    proxy = _horiz_proxy_m(clue_dist, best)
    if proxy >= 3.5:
        return False
    return True


def _descend_while_closing_action(
    flight: FlightState,
    depth: DepthFeatures,
    candidate: TargetCandidate,
    clue_dir_x: float,
    clue_dir_y: float,
    clue_dist: float,
) -> tuple[float, float, float, float, float]:
    """Couple slow horizontal close with early vertical descent."""
    lat = float(np.clip(candidate.image_x, -1.0, 1.0))
    world_x, world_y = _target_world_dir(flight, candidate)
    yaw = flight.yaw
    fx, fy = float(np.cos(yaw)), float(np.sin(yaw))
    sx, sy = float(np.sin(yaw)), float(-np.cos(yaw))

    if abs(lat) > 0.10:
        lateral_cmd = lat * 0.78
        forward_cmd = 0.08
    elif abs(lat) > 0.05:
        lateral_cmd = lat * 0.55
        forward_cmd = 0.11
    else:
        lateral_cmd = lat * 0.28
        forward_cmd = 0.14 if clue_dist > 2.2 else 0.08

    dir_x = fx * forward_cmd + sx * lateral_cmd
    dir_y = fy * forward_cmd + sy * lateral_cmd
    dir_x = dir_x * 0.50 + world_x * 0.50
    dir_y = dir_y * 0.50 + world_y * 0.50
    if clue_dist < 3.2 and candidate.consistency_count >= 4:
        dir_x = dir_x * 0.92 + clue_dir_x * 0.08
        dir_y = dir_y * 0.92 + clue_dir_y * 0.08
    elif clue_dist < 3.2:
        dir_x = dir_x * 0.58 + clue_dir_x * 0.42
        dir_y = dir_y * 0.58 + clue_dir_y * 0.42

    surface_m = _estimate_surface_m(candidate, depth, clue_dist=clue_dist)
    if candidate.consistency_count >= 4 and candidate.range_m < 8.0:
        dir_z = _final_slot_descent_z(surface_m, depth, range_m=candidate.range_m)
        mag = 0.36 if abs(lat) > 0.08 else 0.28
        n = max(np.hypot(dir_x, dir_y), 1e-3)
        dir_x, dir_y = dir_x / n * mag, dir_y / n * mag
        speed = 0.32 if abs(lat) > 0.08 else 0.28
    elif clue_dist > 2.4:
        mag = 0.42 if abs(lat) > 0.08 else 0.32
        n = max(np.hypot(dir_x, dir_y), 1e-3)
        dir_x, dir_y = dir_x / n * mag, dir_y / n * mag
        if surface_m > _DESCENT_STAGE1_M + 0.5:
            dir_z = -0.40
        elif surface_m > _SAR_HOVER_HI_M + 0.35:
            dir_z = -0.32
        else:
            dir_z = -0.14
        speed = 0.18 if abs(lat) > 0.08 else 0.16
    else:
        n = max(np.hypot(dir_x, dir_y), 1e-3)
        mag = 0.30 if abs(lat) > 0.08 else 0.22
        dir_x, dir_y = dir_x / n * mag, dir_y / n * mag
        if surface_m > _DESCENT_STAGE1_M + 0.5:
            dir_z = -0.52
        elif surface_m > _SAR_HOVER_HI_M + 0.35:
            dir_z = -0.44
        elif surface_m > _SAR_HOVER_TARGET_M + 0.20:
            dir_z = -0.30
        elif surface_m > _SAR_HOVER_LO_M + 0.15:
            dir_z = -0.16
        elif surface_m < _SAR_HOVER_LO_M - 0.20:
            dir_z = 0.08
        else:
            dir_z = -0.06
        speed = 0.15 if abs(lat) > 0.08 else 0.13

    speed = float(np.clip(speed, 0.12, 0.35))
    yaw_cmd = float(np.clip((flight.yaw + lat * 0.32) / np.pi, -1.0, 1.0))
    return dir_x, dir_y, dir_z, speed, yaw_cmd


def _creep_action(
    flight: FlightState,
    depth: DepthFeatures,
    candidate: TargetCandidate,
    clue_dir_x: float,
    clue_dir_y: float,
    clue_dist: float,
    *,
    stall_sweep: bool,
    sweep_sign: float,
) -> tuple[float, float, float, float, float, float, float]:
    """Slow lateral-first close over the victim before final hover."""
    yaw = flight.yaw
    fx, fy = float(np.cos(yaw)), float(np.sin(yaw))
    sx, sy = float(np.sin(yaw)), float(-np.cos(yaw))
    lat = float(np.clip(candidate.image_x, -1.0, 1.0))
    world_x, world_y = _target_world_dir(flight, candidate)

    if stall_sweep:
        lateral_cmd = 0.58 * sweep_sign
        forward_cmd = 0.06
    elif abs(lat) > 0.12:
        lateral_cmd = lat * 0.95
        forward_cmd = 0.06
    elif abs(lat) > 0.06:
        lateral_cmd = lat * 0.72
        forward_cmd = 0.12
    else:
        lateral_cmd = lat * 0.40
        forward_cmd = 0.20 if clue_dist > 2.6 else 0.14

    dir_x = fx * forward_cmd + sx * lateral_cmd
    dir_y = fy * forward_cmd + sy * lateral_cmd
    dir_x = dir_x * 0.55 + world_x * 0.45
    dir_y = dir_y * 0.55 + world_y * 0.45
    if 1.5 < clue_dist < 4.0 and candidate.consistency_count < 4:
        dir_x = dir_x * 0.62 + clue_dir_x * 0.38
        dir_y = dir_y * 0.62 + clue_dir_y * 0.38
    n = max(np.hypot(dir_x, dir_y), 1e-3)
    mag = 0.48 if abs(lat) > 0.08 else 0.34
    dir_x, dir_y = dir_x / n * mag, dir_y / n * mag

    surface_m = _estimate_surface_m(candidate, depth, clue_dist=clue_dist)
    if candidate.consistency_count >= 4:
        dir_z = _final_slot_descent_z(surface_m, depth, range_m=candidate.range_m)
        speed = 0.30 if abs(lat) > 0.08 else 0.26
    elif clue_dist < 3.5 and surface_m > _SAR_HOVER_HI_M + 0.3:
        dir_z = -0.38
    elif surface_m > _DESCENT_STAGE1_M + 0.3:
        dir_z = -0.08
    elif surface_m > _SAR_HOVER_HI_M + 0.5:
        dir_z = -0.04
    else:
        dir_z = 0.03
        speed = 0.20 if abs(lat) > 0.08 else 0.16

    if candidate.consistency_count < 4:
        speed = 0.20 if abs(lat) > 0.08 else 0.16
    speed = float(np.clip(speed, 0.12, 0.35))
    yaw_cmd = float(np.clip((flight.yaw + lat * 0.38 + sweep_sign * 0.03) / np.pi, -1.0, 1.0))
    return dir_x, dir_y, dir_z, speed, yaw_cmd, lateral_cmd, forward_cmd


def _update_phase_sar(
    *,
    clue_dist: float,
    recovery: bool,
    tracker: TargetTracker,
    hover_ready: bool,
    search_steps: int,
    descent_allowed: bool,
    best: TargetCandidate | None,
    creep_enter: bool,
    descend_closing: bool,
    force_target_align: bool,
) -> MissionPhase:
    if recovery:
        return MissionPhase.RECOVERY
    if force_target_align and tracker.locked:
        return MissionPhase.TARGET_ALIGN
    if hover_ready and tracker.locked:
        return MissionPhase.HOVER_CONFIRM
    if descend_closing and tracker.locked:
        return MissionPhase.DESCEND_WHILE_CLOSING
    if creep_enter and tracker.locked:
        return MissionPhase.CREEP_OVER_TARGET
    if tracker.locked and descent_allowed and clue_dist < 5.0:
        return MissionPhase.DESCEND_LOCKED
    if tracker.locked:
        return MissionPhase.TARGET_ALIGN
    if (
        best is not None
        and best.rgb_score >= 0.22
        and clue_dist < 22.0
        and best.range_m < 16.0
    ):
        return MissionPhase.TARGET_ALIGN
    if clue_dist < 30.0:
        if search_steps > 200 and tracker.search_ring == 1:
            tracker.set_search_ring(2)
        return MissionPhase.SEARCH_RING_2 if tracker.search_ring >= 2 else MissionPhase.SEARCH_RING_1
    if clue_dist < 50.0:
        return MissionPhase.APPROACH
    return MissionPhase.TRANSIT


def _hold_search_altitude(alt_norm: float) -> float:
    if alt_norm < _SEARCH_ALT_LO:
        return 0.18
    if alt_norm > _SEARCH_ALT_HI:
        return -0.12
    if alt_norm > (_SEARCH_ALT_LO + _SEARCH_ALT_HI) * 0.5 + 0.03:
        return -0.05
    if alt_norm < (_SEARCH_ALT_LO + _SEARCH_ALT_HI) * 0.5 - 0.03:
        return 0.06
    return 0.0


def _spiral_direction(
    clue_xy: np.ndarray,
    *,
    spiral_angle: float,
    search_steps: int,
    search_radius_max: float,
) -> tuple[float, float]:
    """Expanding orbit around the clue center (victim within search_radius_max)."""
    cx, cy = float(clue_xy[0]), float(clue_xy[1])
    dist = float(np.hypot(cx, cy))
    ring_radius = min(search_radius_max, 6.0 + search_steps * 0.08)
    tangent_x, tangent_y = -cy, cx
    t_norm = max(np.hypot(tangent_x, tangent_y), 1e-3)
    tangent_x /= t_norm
    tangent_y /= t_norm

    if dist < 1.5:
        desired_r = min(6.0, 3.5 + search_steps * 0.02)
        inward_x, inward_y = cx / max(dist, 0.3), cy / max(dist, 0.3)
        outward_x, outward_y = -inward_x, -inward_y
        if dist < desired_r:
            mix_t, mix_r = 0.55, 0.45
            radial_x, radial_y = outward_x, outward_y
        else:
            mix_t, mix_r = 0.85, 0.15
            radial_x, radial_y = inward_x, inward_y
        dx = tangent_x * mix_t + radial_x * mix_r
        dy = tangent_y * mix_t + radial_y * mix_r
        norm = max(np.hypot(dx, dy), 1e-3)
        return float(dx / norm), float(dy / norm)

    inward_x, inward_y = cx / dist, cy / dist
    outward_x, outward_y = -inward_x, -inward_y
    if dist > ring_radius + 1.5:
        mix_t, mix_r = 0.30, 0.70
        radial_x, radial_y = inward_x, inward_y
    elif dist < ring_radius - 1.0:
        mix_t, mix_r = 0.80, 0.20
        radial_x, radial_y = outward_x, outward_y
    else:
        mix_t, mix_r = 0.85, 0.15
        radial_x, radial_y = inward_x, inward_y

    dx = tangent_x * mix_t + radial_x * mix_r
    dy = tangent_y * mix_t + radial_y * mix_r
    norm = max(np.hypot(dx, dy), 1e-3)
    return float(dx / norm), float(dy / norm)


def _victim_steer(clue_bearing: float, victim_lateral: float, weight: float = 0.55) -> tuple[float, float]:
    """Blend clue bearing with image-based lateral offset."""
    cb, sb = float(np.cos(clue_bearing)), float(np.sin(clue_bearing))
    # Positive lateral = victim appears right in image -> steer right.
    perp_x, perp_y = -sb, cb
    w = float(np.clip(weight, 0.0, 1.0))
    lat = float(np.clip(victim_lateral, -1.0, 1.0))
    dx = cb * (1.0 - w) + (cb + perp_x * lat) * w
    dy = sb * (1.0 - w) + (sb + perp_y * lat) * w
    norm = max(np.hypot(dx, dy), 1e-3)
    return float(dx / norm), float(dy / norm)


# ---------------------------------------------------------------------------
# Safety shield
# ---------------------------------------------------------------------------


def _obstacle_steer(depth: DepthFeatures) -> tuple[float, float, float]:
    """Return (dir_x, dir_y, speed_scale) from free-depth sectors."""
    sectors = [
        (depth.left_min, 1.0, 0.0),
        (depth.right_min, -1.0, 0.0),
        (depth.front_min, 0.0, 1.0),
    ]
    tight = depth.front_min < 0.22 or depth.clearance < 0.08
    if not tight:
        return 0.0, 0.0, 1.0
    best = max(sectors, key=lambda s: s[0])
    scale = 0.55 if depth.front_min < 0.14 else 0.78
    return best[1] * 0.55, best[2] * 0.55, scale


def _apply_safety_shield(
    action: np.ndarray,
    depth: DepthFeatures,
    *,
    near_target: bool,
    hover_phase: bool,
    allow_descent: bool = False,
    creep_phase: bool = False,
) -> np.ndarray:
    out = np.asarray(action, dtype=np.float32).copy()
    dir_x, dir_y, dir_z, speed, yaw, rgb_req = out

    danger = depth.front_min < 0.14
    real_obstacle = depth.front_min < 0.10 or depth.clearance < 0.05
    side_left_tight = depth.left_min < 0.12
    side_right_tight = depth.right_min < 0.12
    low_clearance = depth.bottom_min < 0.08 or depth.clearance < 0.06

    if danger and not allow_descent and not creep_phase:
        speed *= 0.55
        if depth.left_min > depth.right_min + 0.05:
            dir_x = max(dir_x, 0.45)
        elif depth.right_min > depth.left_min + 0.05:
            dir_x = min(dir_x, -0.45)
        dir_z = max(dir_z, 0.20)
    elif danger and (allow_descent or creep_phase):
        speed *= 0.82 if creep_phase else 0.75
        dir_x = float(np.clip(dir_x * 0.75, -0.45, 0.45))
        dir_y = float(np.clip(dir_y * 0.75, -0.45, 0.45))
        if creep_phase and real_obstacle and depth.front_min < 0.06:
            dir_z = max(dir_z, 0.08)
            speed *= 0.85

    if side_left_tight:
        dir_x = max(dir_x, 0.2)
        speed *= 0.92
    if side_right_tight:
        dir_x = min(dir_x, -0.2)
        speed *= 0.92

    if low_clearance and near_target and not hover_phase and not creep_phase and not allow_descent:
        dir_z = max(dir_z, 0.10)
        speed *= 0.88

    if depth.top_min < 0.12:
        dir_z = min(dir_z, -0.1)

    if hover_phase:
        speed = min(speed, 0.35)
        dir_z = float(np.clip(dir_z, -0.15, 0.15))
        dir_x = float(np.clip(dir_x, -0.35, 0.35))
        dir_y = float(np.clip(dir_y, -0.35, 0.35))

    out[0] = float(np.clip(dir_x, -1.0, 1.0))
    out[1] = float(np.clip(dir_y, -1.0, 1.0))
    out[2] = float(np.clip(dir_z, -1.0, 1.0))
    out[3] = float(np.clip(speed, 0.0, 1.0))
    out[4] = float(np.clip(yaw, -1.0, 1.0))
    out[5] = float(np.clip(rgb_req, 0.0, 1.0))
    return out


# ---------------------------------------------------------------------------
# RGB scheduler
# ---------------------------------------------------------------------------


@dataclass
class _RgbScheduler:
    max_requests: int = 40
    used: int = 0
    steps_since_request: int = 999
    min_interval_steps: int = 4

    def reset(self) -> None:
        self.used = 0
        self.steps_since_request = 999

    def should_request(self, *, phase_needs_rgb: bool, uncertain: bool, near_clue: bool) -> bool:
        if self.used >= self.max_requests:
            return False
        if self.steps_since_request < self.min_interval_steps:
            return False
        if not phase_needs_rgb:
            return False
        return uncertain or near_clue

    def record(self, requested: bool) -> None:
        if requested:
            self.used += 1
            self.steps_since_request = 0
        else:
            self.steps_since_request += 1


# ---------------------------------------------------------------------------
# Optional compact policy
# ---------------------------------------------------------------------------


if _TORCH:

    class _VictimPerceptionNet(nn.Module):
        """Tiny RGB+depth victim localizer: 32×32 heatmap, confidence, range."""

        HEATMAP = 32

        def __init__(self) -> None:
            super().__init__()
            self.backbone = nn.Sequential(
                nn.Conv2d(4, 16, 3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(16, 32, 3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, 64, 3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(64, 64, 3, stride=1, padding=1),
                nn.ReLU(inplace=True),
            )
            self.heatmap_head = nn.Conv2d(64, 1, kernel_size=1)
            self.scalar = nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
                nn.Linear(64, 32),
                nn.ReLU(inplace=True),
            )
            self.conf_head = nn.Linear(32, 1)
            self.range_head = nn.Linear(32, 1)

        def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
            feat = self.backbone(x)
            heat = torch.sigmoid(self.heatmap_head(feat))
            pooled = self.scalar(feat)
            conf = torch.sigmoid(self.conf_head(pooled))
            rng = torch.sigmoid(self.range_head(pooled))
            return heat, conf, rng


class _DetectorRunner:
    """Loads detector.pt and produces VictimDetection from RGB+depth frames."""

    def __init__(self, agent_dir: Path) -> None:
        self._model = None
        self._enabled = os.environ.get("SWARM_DISABLE_DETECTOR", "0") != "1"
        if not _TORCH or not self._enabled:
            return
        weight_path = agent_dir / "detector.pt"
        if not weight_path.is_file():
            return
        self._model = _VictimPerceptionNet()
        state = torch.load(weight_path, map_location="cpu", weights_only=True)
        self._model.load_state_dict(state)
        self._model.eval()

    @property
    def active(self) -> bool:
        return self._model is not None

    def detect(
        self,
        depth: np.ndarray,
        rgb: np.ndarray | None,
        *,
        rgb_valid: bool,
    ) -> VictimDetection | None:
        if self._model is None or not _TORCH:
            return None
        d = np.asarray(depth, dtype=np.float32)
        if d.ndim == 3:
            d = d[:, :, 0]
        r = np.zeros((d.shape[0], d.shape[1], 3), dtype=np.float32)
        if rgb_valid and rgb is not None:
            rr = np.asarray(rgb, dtype=np.float32)
            if rr.ndim == 3 and rr.shape[-1] >= 3:
                r = rr[..., :3]
        tensor = np.concatenate([d[..., None], r], axis=-1)
        t = torch.from_numpy(tensor).permute(2, 0, 1).unsqueeze(0)
        with torch.no_grad():
            heat, conf, rng = self._model(t)
        return _decode_detector_output(
            heat.squeeze(0).squeeze(0).numpy(),
            float(conf.item()),
            float(rng.item()),
            rgb_valid=rgb_valid,
        )


def _decode_detector_output(
    heatmap: np.ndarray,
    conf: float,
    range_norm: float,
    *,
    rgb_valid: bool,
) -> VictimDetection:
    hm = np.asarray(heatmap, dtype=np.float32)
    peak = float(hm.max()) if hm.size else 0.0
    if peak < 0.04:
        return VictimDetection(0.0, 0.0, False, "cnn", range_norm=float(range_norm))
    py, px = np.unravel_index(int(np.argmax(hm)), hm.shape)
    h, w = hm.shape
    lateral = float(np.clip((px / max(w - 1, 1) - 0.5) * 2.0, -1.0, 1.0))
    rgb_boost = 1.0 if rgb_valid else 0.78
    score = float(np.clip(conf * 0.50 + peak * 0.50, 0.0, 1.0)) * rgb_boost
    locked = score > 0.30 and abs(lateral) < 0.22 and conf > 0.32
    return VictimDetection(score, lateral, locked, "cnn", range_norm=float(range_norm))


if _TORCH:

    class _CompactPolicy(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.encoder = nn.Sequential(
                nn.Conv2d(1, 16, 5, stride=2, padding=2),
                nn.ReLU(inplace=True),
                nn.Conv2d(16, 32, 3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, 64, 3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.AdaptiveAvgPool2d((4, 4)),
                nn.Flatten(),
            )
            self.state_mlp = nn.Sequential(
                nn.Linear(8, 32),
                nn.ReLU(inplace=True),
                nn.Linear(32, 32),
                nn.ReLU(inplace=True),
            )
            self.head = nn.Sequential(
                nn.Linear(64 * 4 * 4 + 32, 128),
                nn.ReLU(inplace=True),
                nn.Linear(128, 5),
                nn.Tanh(),
            )

        def forward(self, depth: torch.Tensor, state_vec: torch.Tensor) -> torch.Tensor:
            feat = self.encoder(depth)
            s = self.state_mlp(state_vec)
            return self.head(torch.cat([feat, s], dim=-1))


class _PolicyRunner:
    def __init__(self, agent_dir: Path) -> None:
        self._model = None
        if not _TORCH:
            return
        if os.environ.get("SWARM_USE_NEURAL", "0") != "1":
            return
        weight_path = agent_dir / "policy.pt"
        if not weight_path.is_file():
            return
        self._model = _CompactPolicy()
        state = torch.load(weight_path, map_location="cpu", weights_only=True)
        self._model.load_state_dict(state)
        self._model.eval()

    def propose(self, depth: np.ndarray, state_features: np.ndarray) -> np.ndarray | None:
        if self._model is None or not _TORCH:
            return None
        d = np.asarray(depth, dtype=np.float32)
        if d.ndim == 3:
            d = d[:, :, 0]
        d_t = torch.from_numpy(d).unsqueeze(0).unsqueeze(0)
        s_t = torch.from_numpy(np.asarray(state_features, dtype=np.float32)).unsqueeze(0)
        with torch.no_grad():
            out = self._model(d_t, s_t).squeeze(0).numpy()
        action = np.zeros(6, dtype=np.float32)
        action[0:3] = out[0:3]
        action[3] = float(np.clip((out[3] + 1.0) * 0.5, 0.0, 1.0))
        action[4] = out[4]
        action[5] = 0.0
        return action


# ---------------------------------------------------------------------------
# Controller
# ---------------------------------------------------------------------------


class DroneFlightController:
    """V5 SAR: multi-frame victim localization, then hover 2–4 m overhead for 2 s."""

    MAX_RGB_REQUESTS = 40
    CLUE_RADIUS_HINT = 30.0
    HOVER_SPEED_MAX = 1.0
    HOVER_HORIZ_MAX = 2.0

    def __init__(self) -> None:
        self._agent_dir = Path(__file__).resolve().parent
        self._policy = _PolicyRunner(self._agent_dir)
        self._detector = _DetectorRunner(self._agent_dir)
        self._rgb = _RgbScheduler(max_requests=self.MAX_RGB_REQUESTS)
        self._telemetry_enabled = os.environ.get("SWARM_LOCAL_TELEMETRY", "0") == "1"
        self._telemetry: list[dict] = []
        self._step = 0
        self._phase = MissionPhase.TRANSIT
        self._target_locked = False
        self._tracker = TargetTracker()
        self._search_steps = 0
        self._descent_stage = 0
        self._spiral_angle = 0.0
        self._victim_lateral = 0.0
        self._locked_lateral = 0.0
        self._creep_steps = 0
        self._creep_stall_steps = 0
        self._creep_low_conf_steps = 0
        self._creep_prev_proxy: float | None = None
        self._creep_lateral_cmd = 0.0
        self._creep_forward_cmd = 0.0
        self._target_centered_streak = 0
        self._creep_sweep_sign = 1.0
        self._hover_ready_reason = "init"
        self._dense_obstacle_streak = 0
        self._descend_closing_steps = 0
        self._surface_estimate_m = 0.0

    def act(self, observation: dict) -> np.ndarray:
        depth_raw = np.asarray(observation["depth"], dtype=np.float32)
        rgb = np.asarray(observation.get("rgb"), dtype=np.float32)
        flight = _parse_state(np.asarray(observation["state"], dtype=np.float32))
        depth = _analyze_depth(depth_raw)

        clue_dist = float(np.linalg.norm(flight.search_clue_xy))
        clue_bearing = float(np.arctan2(flight.search_clue_xy[1], flight.search_clue_xy[0]))

        rgb_det = None
        rgb_frame_valid = rgb.size > 0 and float(np.max(rgb)) > 0.01
        cnn_det = self._detector.detect(depth_raw, rgb if rgb_frame_valid else None, rgb_valid=rgb_frame_valid)
        if cnn_det is not None and cnn_det.score > 0.12:
            rgb_det = cnn_det
        elif rgb_frame_valid:
            rgb_det = _detect_victim_rgb(rgb)
        victim = _fuse_victim_detection(depth, rgb_det)

        self._tracker.observe(
            self._step, flight, depth, rgb_det, rgb_frame_valid=rgb_frame_valid,
            cnn_det=cnn_det, clue_dist=clue_dist,
        )
        best = self._tracker.best()
        descent_allowed = self._tracker.descent_allowed(self._step, clue_dist)
        if best is not None:
            self._surface_estimate_m = _estimate_surface_m(best, depth, clue_dist=clue_dist)

        if clue_dist < 30.0:
            self._search_steps += 1
        else:
            self._search_steps = max(0, self._search_steps - 1)

        hover_ready, self._hover_ready_reason = self._hover_predicate(
            flight, depth, victim, best, descent_allowed, clue_dist
        )
        if (
            self._phase == MissionPhase.HOVER_CONFIRM
            and best is not None
            and clue_dist < 2.3
            and self._surface_estimate_m < _SAR_HOVER_HI_M + 0.75
        ):
            hover_ready = True
            self._hover_ready_reason = "hover_hold"

        if best is not None and abs(best.image_x) < 0.12:
            self._target_centered_streak += 1
        else:
            self._target_centered_streak = max(0, self._target_centered_streak - 1)

        conf_score = best.combined_score if best else 0.0
        if best is not None and conf_score < 0.16:
            self._creep_low_conf_steps += 1
        else:
            self._creep_low_conf_steps = 0
        force_target_align = self._creep_low_conf_steps >= 30

        horiz_proxy = _horiz_proxy_m(clue_dist, best)
        creep_enter = _creep_active(
            locked=self._tracker.locked,
            clue_dist=clue_dist,
            best=best,
            hover_ready=hover_ready,
            force_target_align=force_target_align,
        )
        descend_closing = _descend_while_closing_active(
            locked=self._tracker.locked,
            clue_dist=clue_dist,
            best=best,
            depth=depth,
            hover_ready=hover_ready,
            force_target_align=force_target_align,
            descent_allowed=descent_allowed,
        )
        if descend_closing:
            self._descend_closing_steps += 1

        if creep_enter:
            if self._creep_prev_proxy is not None and horiz_proxy < self._creep_prev_proxy - 0.04:
                self._creep_stall_steps = 0
            else:
                self._creep_stall_steps += 1
            self._creep_steps += 1
            if self._creep_stall_steps >= 100:
                self._creep_sweep_sign *= -1.0
                self._creep_stall_steps = 0
        else:
            self._creep_stall_steps = 0
        self._creep_prev_proxy = horiz_proxy

        dense_obstacle = (
            depth.front_min < 0.22
            and (depth.left_min < 0.16 or depth.right_min < 0.16 or depth.clearance < 0.08)
        )
        if dense_obstacle:
            self._dense_obstacle_streak = min(self._dense_obstacle_streak + 1, 600)
        else:
            self._dense_obstacle_streak = max(0, self._dense_obstacle_streak - 2)

        recovery = (
            depth.front_min < 0.05
            and flight.altitude_norm > 0.18
            and self._step > 90
            and depth.left_min < 0.10
            and depth.right_min < 0.10
        )
        self._phase = _update_phase_sar(
            clue_dist=clue_dist,
            recovery=recovery,
            tracker=self._tracker,
            hover_ready=hover_ready,
            search_steps=self._search_steps,
            descent_allowed=descent_allowed,
            best=best,
            creep_enter=creep_enter,
            descend_closing=descend_closing,
            force_target_align=force_target_align,
        )

        self._target_locked = self._tracker.locked
        if best is not None:
            self._victim_lateral = best.image_x
            if self._tracker.locked:
                self._locked_lateral = best.image_x

        action = self._heuristic_action(
            flight, depth, clue_dist, clue_bearing, victim, rgb_det, best, descent_allowed
        )

        near_target = self._phase in (
            MissionPhase.TARGET_ALIGN,
            MissionPhase.DESCEND_WHILE_CLOSING,
            MissionPhase.DESCEND_LOCKED,
            MissionPhase.CREEP_OVER_TARGET,
            MissionPhase.HOVER_CONFIRM,
        )
        hover_phase = self._phase == MissionPhase.HOVER_CONFIRM
        creep_phase = self._phase in (
            MissionPhase.CREEP_OVER_TARGET,
            MissionPhase.DESCEND_WHILE_CLOSING,
        ) or (
            self._phase == MissionPhase.DESCEND_LOCKED
            and best is not None
            and clue_dist < 2.0
        ) or (
            self._phase == MissionPhase.TARGET_ALIGN
            and self._tracker.locked
            and best is not None
            and best.consistency_count >= 4
        )
        allow_descent = descent_allowed and (
            self._phase in (
                MissionPhase.DESCEND_WHILE_CLOSING,
                MissionPhase.DESCEND_LOCKED,
                MissionPhase.CREEP_OVER_TARGET,
                MissionPhase.HOVER_CONFIRM,
            )
            or (
                self._phase == MissionPhase.TARGET_ALIGN
                and self._tracker.locked
            )
        )
        action = _apply_safety_shield(
            action,
            depth,
            near_target=near_target,
            hover_phase=hover_phase,
            allow_descent=allow_descent,
            creep_phase=creep_phase,
        )

        want_rgb = False
        if clue_dist > 30.0:
            want_rgb = False
        elif clue_dist > 12.0:
            want_rgb = self._step % 9 == 0 and self._rgb.used < self._rgb.max_requests
        elif self._tracker.locked:
            want_rgb = self._step % 3 == 0 and self._rgb.used < self._rgb.max_requests
        else:
            want_rgb = self._step % 4 == 0 and self._rgb.used < self._rgb.max_requests
        if self._phase in (
            MissionPhase.TARGET_ALIGN,
            MissionPhase.DESCEND_WHILE_CLOSING,
            MissionPhase.DESCEND_LOCKED,
            MissionPhase.CREEP_OVER_TARGET,
        ):
            want_rgb = want_rgb or (self._step % 2 == 0 and self._rgb.used < self._rgb.max_requests)
        action[5] = 1.0 if want_rgb else 0.0
        self._rgb.record(bool(action[5] > 0.5))

        if self._telemetry_enabled:
            self._telemetry.append(
                {
                    "step": self._step,
                    "phase": self._phase.name,
                    "clue_dist": clue_dist,
                    "candidate_count": self._tracker.count(),
                    "best_candidate_score": best.combined_score if best else 0.0,
                    "target_bearing": best.bearing if best else 0.0,
                    "target_range_m": best.range_m if best else 0.0,
                    "rgb_confirm_streak": best.consistency_count if best else 0,
                    "detector_active": self._detector.active,
                    "cnn_score": cnn_det.score if cnn_det else 0.0,
                    "descent_allowed_reason": self._tracker.descent_reason,
                    "target_locked": self._tracker.locked,
                    "search_ring": self._tracker.search_ring,
                    "rgb_used": self._rgb.used,
                    "action_speed": float(action[3]),
                    "creep_steps": self._creep_steps,
                    "creep_lateral_cmd": self._creep_lateral_cmd,
                    "creep_forward_cmd": self._creep_forward_cmd,
                    "target_centered_streak": self._target_centered_streak,
                    "hover_ready_reason": self._hover_ready_reason,
                    "horiz_proxy_m": horiz_proxy,
                    "descend_closing_steps": self._descend_closing_steps,
                    "surface_estimate_m": self._surface_estimate_m,
                }
            )

        self._tracker.note_range()
        self._tracker._yaw_sweep += 0.055
        self._spiral_angle += 0.08
        self._step += 1
        return np.asarray(action, dtype=np.float32)

    def reset(self) -> None:
        self._rgb.reset()
        self._telemetry.clear()
        self._tracker.reset()
        self._step = 0
        self._phase = MissionPhase.TRANSIT
        self._target_locked = False
        self._search_steps = 0
        self._descent_stage = 0
        self._spiral_angle = float(np.random.uniform(0, 2 * np.pi))
        self._victim_lateral = 0.0
        self._locked_lateral = 0.0
        self._creep_steps = 0
        self._creep_stall_steps = 0
        self._creep_low_conf_steps = 0
        self._creep_prev_proxy = None
        self._creep_lateral_cmd = 0.0
        self._creep_forward_cmd = 0.0
        self._target_centered_streak = 0
        self._creep_sweep_sign = 1.0
        self._hover_ready_reason = "reset"
        self._dense_obstacle_streak = 0
        self._descend_closing_steps = 0
        self._surface_estimate_m = 0.0

    def get_telemetry(self) -> list[dict]:
        return list(self._telemetry)

    def _heuristic_action(
        self,
        flight: FlightState,
        depth: DepthFeatures,
        clue_dist: float,
        clue_bearing: float,
        victim: VictimDetection,
        rgb_det: VictimDetection | None,
        best: TargetCandidate | None,
        descent_allowed: bool,
    ) -> np.ndarray:
        action = np.zeros(6, dtype=np.float32)
        alt = flight.altitude_norm
        clue_xy = flight.search_clue_xy
        if clue_dist > 1e-3:
            clue_dir_x = float(clue_xy[0] / clue_dist)
            clue_dir_y = float(clue_xy[1] / clue_dist)
        else:
            clue_dir_x = float(np.cos(clue_bearing))
            clue_dir_y = float(np.sin(clue_bearing))

        dir_x, dir_y, dir_z, speed = clue_dir_x, clue_dir_y, 0.0, 0.75
        yaw = float(np.clip(clue_bearing / np.pi, -1.0, 1.0))

        if self._phase == MissionPhase.RECOVERY:
            dir_x, dir_y, dir_z, speed = 0.0, 0.0, 0.35, 0.40
        elif self._phase == MissionPhase.TRANSIT or clue_dist > 30.0:
            dir_z = 0.12 if alt < 0.18 else 0.0
            speed = 0.88
        elif self._phase == MissionPhase.APPROACH:
            dir_z = _hold_search_altitude(alt)
            forest_like = self._dense_obstacle_streak > 40
            speed = 0.58 if clue_dist > 18.0 else 0.44
            if forest_like:
                speed = min(speed, 0.36 if clue_dist > 18.0 else 0.28)
            if depth.front_min < 0.20:
                speed = min(speed, 0.34 if forest_like else 0.38)
                if forest_like and depth.front_min < 0.16:
                    dir_z = max(dir_z, 0.16)
                else:
                    dir_z = max(dir_z, 0.10)
            if depth.front_min < 0.14 or depth.left_min < 0.12 or depth.right_min < 0.12:
                speed = min(speed, 0.26 if forest_like else 0.32)
                dir_z = max(dir_z, 0.16 if forest_like else 0.14)
            if forest_like and depth.front_min < 0.17:
                dir_x *= 0.50
                dir_y *= 0.50
                dir_z = max(dir_z, 0.18)
        elif self._phase == MissionPhase.SEARCH_RING_1:
            ring_r = 6.0
            dir_x, dir_y = _ring_orbit_dir(
                clue_xy, ring_radius=ring_r, sweep_angle=self._tracker._yaw_sweep
            )
            dir_x = dir_x * 0.82 + clue_dir_x * 0.18
            dir_y = dir_y * 0.82 + clue_dir_y * 0.18
            n = max(np.hypot(dir_x, dir_y), 1e-3)
            dir_x, dir_y = dir_x / n, dir_y / n
            dir_z = _hold_search_altitude(alt)
            speed = 0.38 if depth.front_min < 0.16 else 0.42
            yaw = float(np.clip((flight.yaw + 0.07) / np.pi, -1.0, 1.0))
            if best is not None and best.rgb_score > 0.20 and clue_dist < 14.0:
                cx, cy, speed, yaw = _close_on_target(
                    flight, depth, best, clue_dir_x, clue_dir_y, clue_dist
                )
                dir_x, dir_y = cx, cy
        elif self._phase == MissionPhase.SEARCH_RING_2:
            ring_r = 12.0
            dir_x, dir_y = _ring_orbit_dir(
                clue_xy, ring_radius=ring_r, sweep_angle=self._tracker._yaw_sweep
            )
            dir_x = dir_x * 0.75 + clue_dir_x * 0.25
            dir_y = dir_y * 0.75 + clue_dir_y * 0.25
            n = max(np.hypot(dir_x, dir_y), 1e-3)
            dir_x, dir_y = dir_x / n, dir_y / n
            dir_z = _hold_search_altitude(alt)
            speed = 0.42 if depth.front_min < 0.16 else 0.46
            yaw = float(np.clip((flight.yaw + 0.08) / np.pi, -1.0, 1.0))
        elif self._phase == MissionPhase.TARGET_ALIGN and best is not None:
            dir_x, dir_y, speed, yaw = _close_on_target(
                flight, depth, best, clue_dir_x, clue_dir_y, clue_dist
            )
            if self._tracker.locked and best.consistency_count >= 4:
                dir_z = _final_slot_descent_z(
                    _estimate_surface_m(best, depth, clue_dist=clue_dist),
                    depth,
                    range_m=best.range_m,
                )
                speed = max(speed, 0.28)
            else:
                dir_z = _hold_search_altitude(alt)
        elif self._phase == MissionPhase.DESCEND_WHILE_CLOSING and best is not None:
            dir_x, dir_y, dir_z, speed, yaw = _descend_while_closing_action(
                flight, depth, best, clue_dir_x, clue_dir_y, clue_dist
            )
        elif self._phase == MissionPhase.DESCEND_LOCKED and best is not None:
            surface_m = _estimate_surface_m(best, depth, clue_dist=clue_dist)
            lat = float(np.clip(best.image_x, -1.0, 1.0))
            dir_x, dir_y, speed, yaw = _close_on_target(
                flight, depth, best, clue_dir_x, clue_dir_y, clue_dist, final_zone=True
            )
            if clue_dist > 2.8:
                hn = max(np.hypot(dir_x, dir_y), 1e-3)
                dir_x, dir_y = dir_x / hn * 0.45, dir_y / hn * 0.45
                dir_z = self._locked_descent_command(
                    flight, depth, best, descent_allowed, clue_dist=clue_dist
                )
                speed = min(max(speed, 0.24), 0.34)
            elif clue_dist > 2.0:
                hn = max(np.hypot(dir_x, dir_y), 1e-3)
                scale = 0.44 if clue_dist > 2.35 else 0.34
                dir_x, dir_y = dir_x / hn * scale, dir_y / hn * scale
                if surface_m > _SAR_HOVER_HI_M + 0.55:
                    dir_z = -0.26
                else:
                    dir_z = self._locked_descent_command(
                        flight, depth, best, descent_allowed, clue_dist=clue_dist
                    )
                speed = min(speed, 0.20)
            else:
                wx, wy = _target_world_dir(flight, best)
                dir_x = wx * 0.05 + clue_dir_x * 0.02
                dir_y = wy * 0.05 + clue_dir_y * 0.02
                dir_z = _final_slot_descent_z(surface_m, depth, range_m=best.range_m)
                speed = 0.28
            yaw = float(np.clip((flight.yaw + lat * 0.35) / np.pi, -1.0, 1.0))
        elif self._phase == MissionPhase.CREEP_OVER_TARGET and best is not None:
            stall_sweep = self._creep_stall_steps >= 85
            dir_x, dir_y, dir_z, speed, yaw, lat_cmd, fwd_cmd = _creep_action(
                flight,
                depth,
                best,
                clue_dir_x,
                clue_dir_y,
                clue_dist,
                stall_sweep=stall_sweep,
                sweep_sign=self._creep_sweep_sign,
            )
            self._creep_lateral_cmd = lat_cmd
            self._creep_forward_cmd = fwd_cmd
        elif self._phase == MissionPhase.HOVER_CONFIRM and best is not None:
            dir_x, dir_y = _target_world_dir(flight, best)
            hn = max(np.hypot(dir_x, dir_y), 1e-3)
            dir_x, dir_y = dir_x / hn * 0.05, dir_y / hn * 0.05
            dir_z = self._locked_descent_command(
                flight, depth, best, descent_allowed, clue_dist=clue_dist
            )
            if self._surface_estimate_m > _SAR_HOVER_HI_M + 0.15:
                dir_z = min(dir_z, -0.35)
            speed = _HOVER_FINAL_SPEED
            yaw = float(np.clip((flight.yaw + best.image_x * 0.20) / np.pi, -1.0, 1.0))
        else:
            dir_z = _hold_search_altitude(alt)
            speed = 0.55

        if alt < 0.12 and clue_dist > 8.0 and self._step < 120 and self._phase == MissionPhase.TRANSIT:
            dir_x, dir_y = dir_x * 0.35, dir_y * 0.35
            dir_z, speed = 0.55, 0.55

        if depth.front_min < 0.14 and self._phase not in (
            MissionPhase.DESCEND_WHILE_CLOSING,
            MissionPhase.DESCEND_LOCKED,
            MissionPhase.CREEP_OVER_TARGET,
            MissionPhase.HOVER_CONFIRM,
        ):
            steer_x, steer_y, steer_scale = _obstacle_steer(depth)
            steer_w = 0.45 if self._phase == MissionPhase.TARGET_ALIGN else 0.35
            dir_x = float(np.clip(dir_x * (1.0 - steer_w) + steer_x * steer_w, -1.0, 1.0))
            dir_y = float(np.clip(dir_y * (1.0 - steer_w) + steer_y * steer_w, -1.0, 1.0))
            speed *= max(steer_scale, 0.68 if self._phase == MissionPhase.TARGET_ALIGN else 0.75)

        action[0], action[1], action[2], action[3], action[4], action[5] = (
            dir_x, dir_y, dir_z, speed, yaw, 0.0
        )
        return action

    def _locked_descent_command(
        self,
        flight: FlightState,
        depth: DepthFeatures,
        candidate: TargetCandidate,
        descent_allowed: bool,
        *,
        clue_dist: float = 999.0,
    ) -> float:
        """Descend only when locked; never from floor depth alone."""
        if not descent_allowed:
            return _hold_search_altitude(flight.altitude_norm)

        surface_m = _estimate_surface_m(candidate, depth, clue_dist=clue_dist)
        if candidate.consistency_count >= 4 and clue_dist < 2.5:
            return _final_slot_descent_z(surface_m, depth, range_m=candidate.range_m)

        if candidate.rgb_score < 0.18 and candidate.depth_score < 0.26:
            return _hold_search_altitude(flight.altitude_norm)

        if surface_m > _DESCENT_STAGE1_M + 0.8:
            return -0.42
        if surface_m > _DESCENT_STAGE1_M:
            return -0.28
        if surface_m > _SAR_HOVER_HI_M + 0.6:
            return -0.22
        if surface_m > _SAR_HOVER_TARGET_M + 0.35:
            return -0.14
        if surface_m < _SAR_HOVER_LO_M - 0.35:
            return 0.14
        if surface_m < _SAR_HOVER_TARGET_M - 0.25:
            return 0.06
        return -0.03

    def _hover_predicate(
        self,
        flight: FlightState,
        depth: DepthFeatures,
        victim: VictimDetection,
        best: TargetCandidate | None,
        descent_allowed: bool,
        clue_dist: float,
    ) -> tuple[bool, str]:
        if not self._tracker.locked or best is None or not descent_allowed:
            return False, "not_locked_or_descent"
        if clue_dist >= 2.05 and best.consistency_count < 4:
            return False, f"clue_horiz_{clue_dist:.2f}m"
        if best.consistency_count >= 4:
            proxy = _horiz_proxy_m(clue_dist, best)
            if proxy >= 2.05:
                return False, f"track_horiz_{proxy:.2f}m"
        elif clue_dist >= 2.05:
            return False, f"clue_horiz_{clue_dist:.2f}m"
        surface_m = _estimate_surface_m(best, depth, clue_dist=clue_dist)
        if 0.04 < depth.center_bottom_min < 0.28 and clue_dist < 2.0:
            cb_m = _depth_norm_to_meters(depth.center_bottom_min)
            if _SAR_HOVER_LO_M - 0.30 <= cb_m <= _SAR_HOVER_HI_M + 0.40:
                surface_m = cb_m
        if surface_m < _SAR_HOVER_LO_M - 0.35:
            return False, f"too_low_{surface_m:.2f}m"
        if surface_m > _SAR_HOVER_HI_M + 0.40:
            return False, f"too_high_{surface_m:.2f}m"
        if flight.speed >= 0.42:
            return False, f"speed_{flight.speed:.2f}"
        if self._target_centered_streak < 2:
            return False, f"center_streak_{self._target_centered_streak}"
        if abs(best.image_x) >= 0.14:
            return False, f"off_center_{best.image_x:.3f}"
        if best.consistency_count < 2:
            return False, f"consistency_{best.consistency_count}"
        rgb_floor = 0.10 if clue_dist < 1.95 else 0.14
        if best.rgb_score < rgb_floor and best.depth_score < 0.16:
            return False, f"rgb_{best.rgb_score:.3f}"
        return True, "ready"
